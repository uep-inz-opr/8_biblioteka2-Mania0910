import math

def oblicz_smybol_newtona(n:int, k:int):
    return math.factorial(n) / (math.factorial(k) * math.factorial(n-k))

dane_wejsciowe = input("podaj liczby: ")
tablica_danych_wejsciowych = dane_wejsciowe.split()
n = int(tablica_danych_wejsciowych[0])
k = int(tablica_danych_wejsciowych[1])
print(oblicz_smybol_newtona(n, k))
